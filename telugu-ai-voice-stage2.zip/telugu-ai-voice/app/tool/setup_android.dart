// Run once after `flutter create`:   dart run tool/setup_android.dart
//
// Adds what this app needs to the generated Android project:
//   * INTERNET + RECORD_AUDIO permissions (release builds need INTERNET explicitly)
//   * the "Telugu AI Voice" app name
//   * package-visibility entry so audio links can open in the browser
//   * cleartext HTTP for DEBUG builds only (local server at http://10.0.2.2:8000)
// Safe to run more than once.
import 'dart:io';

void main() {
  final mainManifest = File('android/app/src/main/AndroidManifest.xml');
  final debugManifest = File('android/app/src/debug/AndroidManifest.xml');
  if (!mainManifest.existsSync()) {
    stderr.writeln('android/ not found. First run:  flutter create --platforms=android,web --org com.teluguaivoice --project-name telugu_ai_voice .');
    exit(1);
  }

  var m = mainManifest.readAsStringSync();
  var changed = false;

  for (final permission in ['android.permission.INTERNET', 'android.permission.RECORD_AUDIO']) {
    if (!m.contains(permission)) {
      m = m.replaceFirst('<application', '<uses-permission android:name="$permission"/>\n    <application');
      changed = true;
    }
  }

  final label = RegExp(r'android:label="[^"]*"');
  if (label.hasMatch(m) && !m.contains('android:label="Telugu AI Voice"')) {
    m = m.replaceFirst(label, 'android:label="Telugu AI Voice"');
    changed = true;
  }

  if (!m.contains('android.intent.action.VIEW')) {
    const viewIntent = '''
    <queries>
        <intent>
            <action android:name="android.intent.action.VIEW" />
            <data android:scheme="https" />
        </intent>
        <intent>
            <action android:name="android.intent.action.VIEW" />
            <data android:scheme="http" />
        </intent>''';
    if (m.contains('<queries>')) {
      m = m.replaceFirst(RegExp(r'\s*<queries>'), '\n$viewIntent');
    } else {
      m = m.replaceFirst('</manifest>', '$viewIntent\n    </queries>\n</manifest>');
    }
    changed = true;
  }

  if (changed) {
    mainManifest.writeAsStringSync(m);
    stdout.writeln('Updated ${mainManifest.path}');
  } else {
    stdout.writeln('${mainManifest.path} already set up');
  }

  if (debugManifest.existsSync()) {
    var d = debugManifest.readAsStringSync();
    if (!d.contains('usesCleartextTraffic')) {
      d = d.replaceFirst('</manifest>', '    <application android:usesCleartextTraffic="true" />\n</manifest>');
      debugManifest.writeAsStringSync(d);
      stdout.writeln('Updated ${debugManifest.path} (cleartext HTTP allowed in debug builds only)');
    }
  }
  stdout.writeln('Android setup complete.');
}
