import 'package:flutter/material.dart';

import '../../core/api/api_models.dart';
import '../../core/config/app_config.dart';
import '../../core/feature_status.dart';
import '../../core/state/app_scope.dart';
import '../../core/theme/app_theme.dart';
import '../../widgets/audio_tile.dart';
import '../../widgets/common.dart';
import '../../widgets/telugu_keyboard.dart';

class TtsScreen extends StatefulWidget {
  const TtsScreen({super.key});

  @override
  State<TtsScreen> createState() => _TtsScreenState();
}

class _TtsScreenState extends State<TtsScreen> {
  final TextEditingController _text = TextEditingController(text: AppConfig.sampleTeluguText);
  String _gender = 'female';
  String? _voiceId;
  String? _style;
  double _speed = 1.0;
  double _pitch = 0.0;
  bool _showKeyboard = false;
  bool _busy = false;
  AudioItem? _result;

  @override
  void initState() {
    super.initState();
    _text.addListener(_onTextChanged);
  }

  void _onTextChanged() => setState(() {});

  @override
  void dispose() {
    _text.removeListener(_onTextChanged);
    _text.dispose();
    super.dispose();
  }

  List<Voice> _voicesFor(List<Voice> all) => all.where((v) => v.gender == _gender).toList();

  Voice? _selectedVoice(List<Voice> options) {
    if (options.isEmpty) return null;
    for (final v in options) {
      if (v.id == _voiceId) return v;
    }
    return options.firstWhere((v) => v.available, orElse: () => options.first);
  }

  Future<void> _generate(Voice voice) async {
    FocusScope.of(context).unfocus();
    setState(() => _busy = true);
    final app = AppScope.read(context);
    try {
      final item = await app.api.generateSpeech(
        text: _text.text,
        voiceId: voice.id,
        speed: _speed,
        pitch: voice.supportsPitch ? _pitch : 0,
        style: _style,
      );
      if (!mounted) return;
      setState(() => _result = item);
      showMessage(context, 'Audio ready · ఆడియో సిద్ధం');
    } on ApiException catch (e) {
      if (!mounted) return;
      showMessage(context, e.message, error: true);
      if (e.isProviderMissing) await app.refreshServer();
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final app = AppScope.of(context);
    final theme = Theme.of(context);
    final status = FeatureStatus.of(app, Feature.tts);
    final maxChars = app.health?.limits.maxTtsChars ?? 5000;
    final options = _voicesFor(app.voices);
    final voice = _selectedVoice(options);
    final length = _text.text.trim().characters.length;
    final tooLong = length > maxChars;

    String? blockedReason;
    if (!status.ready) {
      blockedReason = status.message;
    } else if (voice == null) {
      blockedReason = 'No ${_gender == 'female' ? 'female' : 'male'} voice is listed by the server.';
    } else if (!voice.available) {
      blockedReason = 'The ${voice.provider} provider for this voice is not configured. Pick another voice.';
    } else if (length == 0) {
      blockedReason = 'Type some Telugu text first.';
    } else if (tooLong) {
      blockedReason = 'Text is longer than $maxChars characters.';
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Telugu Text to Voice')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.only(top: 8, bottom: 40),
        child: ResponsiveBody(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const ScreenHeading(telugu: 'తెలుగు టెక్స్ట్ నుండి వాయిస్', english: 'Type Telugu, choose a voice, generate audio'),
              const FeatureStatusBanner(feature: Feature.tts),

              // ---- Text ---------------------------------------------------------
              SectionCard(
                title: 'మీ టెక్స్ట్ · Your text',
                icon: Icons.edit_note_rounded,
                trailing: TextButton.icon(
                  onPressed: () {
                    FocusScope.of(context).unfocus();
                    setState(() => _showKeyboard = !_showKeyboard);
                  },
                  icon: Icon(_showKeyboard ? Icons.keyboard_hide_rounded : Icons.keyboard_rounded),
                  label: Text(_showKeyboard ? 'Hide' : 'తెలుగు కీబోర్డ్'),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    TextField(
                      key: const Key('tts-text'),
                      controller: _text,
                      minLines: 5,
                      maxLines: 12,
                      keyboardType: TextInputType.multiline,
                      textInputAction: TextInputAction.newline,
                      style: AppTheme.teluguBody(context),
                      decoration: InputDecoration(
                        hintText: 'ఇక్కడ తెలుగులో టైప్ చేయండి…',
                        counterText: '$length / $maxChars',
                        counterStyle: TextStyle(color: tooLong ? theme.colorScheme.error : theme.colorScheme.outline),
                      ),
                    ),
                    const SizedBox(height: 6),
                    Wrap(
                      spacing: 8,
                      children: [
                        TextButton.icon(
                          onPressed: () => _text.text = AppConfig.sampleTeluguText,
                          icon: const Icon(Icons.auto_awesome_rounded, size: 18),
                          label: const Text('Sample'),
                        ),
                        TextButton.icon(
                          onPressed: _text.clear,
                          icon: const Icon(Icons.clear_rounded, size: 18),
                          label: const Text('Clear'),
                        ),
                      ],
                    ),
                    if (_showKeyboard) ...[
                      const SizedBox(height: 8),
                      TeluguKeyboard(controller: _text, onClose: () => setState(() => _showKeyboard = false)),
                    ],
                    const SizedBox(height: 6),
                    Text(
                      'Tip: on Android you can also add Telugu to Gboard (Settings → Languages) for a full phone keyboard.',
                      style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.outline),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 14),

              // ---- Voice -----------------------------------------------------------
              SectionCard(
                title: 'స్వరం · Voice',
                icon: Icons.record_voice_over_rounded,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    SegmentedButton<String>(
                      segments: const [
                        ButtonSegment(value: 'female', icon: Icon(Icons.woman_rounded), label: Text('స్త్రీ · Female')),
                        ButtonSegment(value: 'male', icon: Icon(Icons.man_rounded), label: Text('పురుష · Male')),
                      ],
                      selected: {_gender},
                      onSelectionChanged: (s) => setState(() {
                        _gender = s.first;
                        _voiceId = null;
                        _style = null;
                        _pitch = 0;
                      }),
                    ),
                    const SizedBox(height: 14),
                    if (options.isEmpty)
                      Text(
                        app.health == null ? 'Voices load when the server is reachable.' : 'No voices configured.',
                        style: TextStyle(color: theme.colorScheme.outline),
                      )
                    else
                      InputDecorator(
                        decoration: const InputDecoration(labelText: 'Voice', contentPadding: EdgeInsets.symmetric(horizontal: 14, vertical: 4)),
                        child: DropdownButtonHideUnderline(
                          child: DropdownButton<String>(
                            key: const Key('voice-dropdown'),
                            isExpanded: true,
                            value: voice?.id,
                            items: [
                              for (final v in options)
                                DropdownMenuItem(
                                  value: v.id,
                                  child: Text(
                                    v.available ? v.displayName : '${v.displayName}  (not configured)',
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                            ],
                            onChanged: (id) => setState(() {
                              _voiceId = id;
                              _style = null;
                              _pitch = 0;
                            }),
                          ),
                        ),
                      ),
                    if (voice?.notes != null) ...[
                      const SizedBox(height: 8),
                      Text(voice!.notes!, style: theme.textTheme.bodySmall),
                    ],
                    const SizedBox(height: 12),
                    if (voice != null && voice.styles.isNotEmpty)
                      InputDecorator(
                        decoration: const InputDecoration(labelText: 'Speaking style', contentPadding: EdgeInsets.symmetric(horizontal: 14, vertical: 4)),
                        child: DropdownButtonHideUnderline(
                          child: DropdownButton<String?>(
                            isExpanded: true,
                            value: _style,
                            items: [
                              const DropdownMenuItem<String?>(value: null, child: Text('Default')),
                              for (final s in voice.styles) DropdownMenuItem<String?>(value: s, child: Text(s)),
                            ],
                            onChanged: (s) => setState(() => _style = s),
                          ),
                        ),
                      )
                    else
                      Text(
                        'Speaking styles: the current providers offer none for Telugu voices.',
                        style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.outline),
                      ),
                    Text(
                      'Accent: standard Telugu. Separate Telangana / Andhra accents are not offered by Google or Azure today.',
                      style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.outline),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 14),

              // ---- Speed & pitch ---------------------------------------------------
              SectionCard(
                title: 'వేగం & పిచ్ · Speed & pitch',
                icon: Icons.tune_rounded,
                trailing: TextButton(
                  onPressed: () => setState(() {
                    _speed = 1.0;
                    _pitch = 0;
                  }),
                  child: const Text('Reset'),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text('Speed  ${_speed.toStringAsFixed(2)}×'),
                    Slider(
                      value: _speed,
                      min: 0.25,
                      max: 2.0,
                      divisions: 35,
                      label: '${_speed.toStringAsFixed(2)}×',
                      onChanged: (voice?.supportsSpeed ?? true) ? (v) => setState(() => _speed = v) : null,
                    ),
                    Text('Pitch  ${_pitch >= 0 ? '+' : ''}${_pitch.toStringAsFixed(0)} semitones'),
                    Slider(
                      value: _pitch,
                      min: -20,
                      max: 20,
                      divisions: 40,
                      label: _pitch.toStringAsFixed(0),
                      onChanged: (voice?.supportsPitch ?? false) ? (v) => setState(() => _pitch = v) : null,
                    ),
                    if (voice != null && !voice.supportsPitch)
                      Text(
                        'This voice does not support pitch changes.',
                        style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.outline),
                      ),
                  ],
                ),
              ),
              const SizedBox(height: 20),

              // ---- Generate -----------------------------------------------------------
              FilledButton.icon(
                key: const Key('generate-button'),
                onPressed: (blockedReason == null && !_busy && voice != null) ? () => _generate(voice) : null,
                icon: _busy
                    ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2.5))
                    : const Icon(Icons.graphic_eq_rounded),
                label: Text(_busy ? 'Generating…' : 'వాయిస్ తయారు చేయండి · Generate audio'),
              ),
              if (blockedReason != null) ...[
                const SizedBox(height: 8),
                Text(
                  blockedReason,
                  key: const Key('generate-blocked-reason'),
                  textAlign: TextAlign.center,
                  style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.outline),
                ),
              ],

              if (_result != null) ...[
                const SizedBox(height: 20),
                SectionCard(
                  title: 'ఫలితం · Result',
                  icon: Icons.check_circle_rounded,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      AudioSummaryTile(item: _result!),
                      const SizedBox(height: 10),
                      const Row(
                        children: [
                          Icon(Icons.share_rounded, size: 18),
                          SizedBox(width: 6),
                          Expanded(child: Text('In-app player and share sheet')),
                          StageTag(3),
                          SizedBox(width: 6),
                          StageTag(7),
                        ],
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Saved to your audio history.',
                        style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.outline),
                      ),
                    ],
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
